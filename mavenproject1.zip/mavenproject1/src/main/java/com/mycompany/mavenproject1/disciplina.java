/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vitor Manuel
 */
public class disciplina {
    private String nome;
    private aluno[] alunos = new aluno[20];
    private professor Professor = new professor();
    private double[] media = new double[20];
    private double[] notas = new double[3];
}
